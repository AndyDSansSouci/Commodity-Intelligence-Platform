# ChainMill Platform - Multi-Commodity Verification System

**Development Status:** ACTIVE DEVELOPMENT  
**Methodology:** Test-Driven Development (TDD)  
**CI/CD:** GitHub Actions with mandatory test gates

## Repository Structure

- `backend/` - NestJS microservices with TDD
- `frontend/` - React application with TDD
- `ml-services/` - Python ML services with TDD
- `blockchain/` - Hyperledger Fabric smart contracts with TDD
- `infrastructure/` - Terraform IaC with validation tests
- `shared/` - Common libraries and utilities

## Development Workflow

1. Write failing test first (Red)
2. Write minimum code to pass test (Green)
3. Refactor while keeping tests green (Refactor)
4. Commit with passing unit tests
5. PR triggers integration tests
6. Merge only when all tests pass

## Quality Gates

- Unit test coverage: >80%
- All unit tests must pass before commit
- All integration tests must pass before merge to main
- No direct commits to main - PRs only
- Minimum 1 approval required
