import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';

interface UserPayload {
  userId: string;
  email: string;
  role: string;
}

interface User {
  id: string;
  email: string;
  password?: string;
  role: string;
}

interface LoginResponse {
  access_token: string;
  user: Omit<User, 'password'>;
}

@Injectable()
export class AuthService {
  private readonly saltRounds = 10;

  // Mock user database - in production this would be replaced with actual database
  private readonly mockUsers = new Map<string, User>([
    [
      'test@example.com',
      {
        id: '123',
        email: 'test@example.com',
        password: '', // Will be set with hashed password
        role: 'user',
      },
    ],
  ]);

  constructor(private readonly jwtService: JwtService) {}

  /**
   * Hash a password using bcrypt
   * @param password - Plain text password to hash
   * @returns Hashed password
   */
  async hashPassword(password: string): Promise<string> {
    if (!password || password.length === 0) {
      throw new Error('Password cannot be empty');
    }

    return bcrypt.hash(password, this.saltRounds);
  }

  /**
   * Compare a plain text password with a hashed password
   * @param password - Plain text password
   * @param hashedPassword - Hashed password to compare against
   * @returns True if passwords match, false otherwise
   */
  async comparePasswords(
    password: string,
    hashedPassword: string,
  ): Promise<boolean> {
    return bcrypt.compare(password, hashedPassword);
  }

  /**
   * Generate a JWT token from user payload
   * @param payload - User data to encode in token
   * @returns JWT token string
   */
  generateToken(payload: UserPayload): string {
    return this.jwtService.sign(payload);
  }

  /**
   * Verify and decode a JWT token
   * @param token - JWT token to verify
   * @returns Decoded payload
   * @throws Error if token is invalid
   */
  verifyToken(token: string): any {
    return this.jwtService.verify(token);
  }

  /**
   * Validate user credentials
   * @param email - User email
   * @param password - User password
   * @returns User object without password if valid, null otherwise
   */
  async validateUser(email: string, password: string): Promise<Omit<User, 'password'> | null> {
    const user = await this.findUserByEmail(email);

    if (!user || !user.password) {
      return null;
    }

    const isPasswordValid = await this.comparePasswords(password, user.password);

    if (!isPasswordValid) {
      return null;
    }

    // Remove password from user object before returning
    const { password: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }

  /**
   * Login a user and generate access token
   * @param user - User object (without password)
   * @returns Login response with access token and user data
   */
  async login(user: Omit<User, 'password'>): Promise<LoginResponse> {
    const payload: UserPayload = {
      userId: user.id,
      email: user.email,
      role: user.role,
    };

    const access_token = this.generateToken(payload);

    return {
      access_token,
      user,
    };
  }

  /**
   * Find user by email - mock implementation
   * In production, this would query the database
   * @param email - User email to search for
   * @returns User object or null if not found
   * @private
   */
  private async findUserByEmail(email: string): Promise<User | null> {
    return this.mockUsers.get(email) || null;
  }
}
