import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from './auth.service';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';

describe('AuthService - TDD', () => {
  let service: AuthService;
  let jwtService: JwtService;

  const mockJwtService = {
    sign: jest.fn(),
    verify: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        {
          provide: JwtService,
          useValue: mockJwtService,
        },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
    jwtService = module.get<JwtService>(JwtService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('hashPassword', () => {
    it('should hash a password using bcrypt', async () => {
      const password = 'testPassword123';
      const hashedPassword = await service.hashPassword(password);

      expect(hashedPassword).toBeDefined();
      expect(hashedPassword).not.toBe(password);
      expect(typeof hashedPassword).toBe('string');

      // Verify it's a valid bcrypt hash
      const isValid = await bcrypt.compare(password, hashedPassword);
      expect(isValid).toBe(true);
    });

    it('should generate different hashes for the same password', async () => {
      const password = 'testPassword123';
      const hash1 = await service.hashPassword(password);
      const hash2 = await service.hashPassword(password);

      expect(hash1).not.toBe(hash2); // Bcrypt includes salt, so hashes differ
    });

    it('should throw error for empty password', async () => {
      await expect(service.hashPassword('')).rejects.toThrow();
    });
  });

  describe('comparePasswords', () => {
    it('should return true for matching password and hash', async () => {
      const password = 'testPassword123';
      const hashedPassword = await bcrypt.hash(password, 10);

      const result = await service.comparePasswords(password, hashedPassword);
      expect(result).toBe(true);
    });

    it('should return false for non-matching password and hash', async () => {
      const password = 'testPassword123';
      const wrongPassword = 'wrongPassword';
      const hashedPassword = await bcrypt.hash(password, 10);

      const result = await service.comparePasswords(wrongPassword, hashedPassword);
      expect(result).toBe(false);
    });
  });

  describe('generateToken', () => {
    it('should generate a JWT token with user payload', () => {
      const payload = { userId: '123', email: 'test@example.com', role: 'user' };
      const expectedToken = 'mock.jwt.token';

      mockJwtService.sign.mockReturnValue(expectedToken);

      const token = service.generateToken(payload);

      expect(mockJwtService.sign).toHaveBeenCalledWith(payload);
      expect(token).toBe(expectedToken);
    });

    it('should generate different tokens for different payloads', () => {
      const payload1 = { userId: '123', email: 'test1@example.com', role: 'user' };
      const payload2 = { userId: '456', email: 'test2@example.com', role: 'admin' };

      mockJwtService.sign.mockReturnValueOnce('token1');
      mockJwtService.sign.mockReturnValueOnce('token2');

      const token1 = service.generateToken(payload1);
      const token2 = service.generateToken(payload2);

      expect(token1).not.toBe(token2);
    });
  });

  describe('verifyToken', () => {
    it('should verify and decode a valid JWT token', () => {
      const token = 'valid.jwt.token';
      const expectedPayload = { userId: '123', email: 'test@example.com' };

      mockJwtService.verify.mockReturnValue(expectedPayload);

      const result = service.verifyToken(token);

      expect(mockJwtService.verify).toHaveBeenCalledWith(token);
      expect(result).toEqual(expectedPayload);
    });

    it('should throw error for invalid token', () => {
      const invalidToken = 'invalid.token';

      mockJwtService.verify.mockImplementation(() => {
        throw new Error('Invalid token');
      });

      expect(() => service.verifyToken(invalidToken)).toThrow('Invalid token');
    });
  });

  describe('validateUser', () => {
    it('should return user data for valid credentials', async () => {
      const email = 'test@example.com';
      const password = 'password123';
      const hashedPassword = await bcrypt.hash(password, 10);

      const mockUser = {
        id: '123',
        email: email,
        password: hashedPassword,
        role: 'user',
      };

      // Mock the user lookup (would be from database in real app)
      jest.spyOn(service as any, 'findUserByEmail').mockResolvedValue(mockUser);

      const result = await service.validateUser(email, password);

      expect(result).toBeDefined();
      expect(result).not.toBeNull();
      if (result) {
        expect(result.id).toBe(mockUser.id);
        expect(result.email).toBe(mockUser.email);
        expect('password' in result).toBe(false); // Password should be removed
      }
    });

    it('should return null for invalid credentials', async () => {
      const email = 'test@example.com';
      const password = 'wrongPassword';
      const hashedPassword = await bcrypt.hash('correctPassword', 10);

      const mockUser = {
        id: '123',
        email: email,
        password: hashedPassword,
        role: 'user',
      };

      jest.spyOn(service as any, 'findUserByEmail').mockResolvedValue(mockUser);

      const result = await service.validateUser(email, password);

      expect(result).toBeNull();
    });

    it('should return null for non-existent user', async () => {
      const email = 'nonexistent@example.com';
      const password = 'password123';

      jest.spyOn(service as any, 'findUserByEmail').mockResolvedValue(null);

      const result = await service.validateUser(email, password);

      expect(result).toBeNull();
    });
  });

  describe('login', () => {
    it('should return access token for valid user', async () => {
      const user = {
        id: '123',
        email: 'test@example.com',
        role: 'user',
      };

      const expectedToken = 'generated.jwt.token';
      mockJwtService.sign.mockReturnValue(expectedToken);

      const result = await service.login(user);

      expect(result).toHaveProperty('access_token');
      expect(result.access_token).toBe(expectedToken);
      expect(mockJwtService.sign).toHaveBeenCalledWith({
        userId: user.id,
        email: user.email,
        role: user.role,
      });
    });

    it('should include user information in login response', async () => {
      const user = {
        id: '123',
        email: 'test@example.com',
        role: 'admin',
      };

      mockJwtService.sign.mockReturnValue('token');

      const result = await service.login(user);

      expect(result).toHaveProperty('user');
      expect(result.user).toEqual(user);
    });
  });
});
