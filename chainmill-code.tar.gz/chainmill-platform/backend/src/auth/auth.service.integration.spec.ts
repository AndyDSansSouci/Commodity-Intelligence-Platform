import { Test, TestingModule } from '@nestjs/testing';
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './auth.service';

/**
 * Integration tests for AuthService
 * These tests verify the complete authentication flow with real dependencies
 */
describe('AuthService Integration Tests', () => {
  let service: AuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [
        JwtModule.register({
          secret: 'test-secret-key',
          signOptions: { expiresIn: '1h' },
        }),
      ],
      providers: [AuthService],
    }).compile();

    service = module.get<AuthService>(AuthService);
  });

  describe('Complete Authentication Flow', () => {
    it('should complete full registration and login flow', async () => {
      // 1. Hash password (simulating user registration)
      const plainPassword = 'SecurePassword123!';
      const hashedPassword = await service.hashPassword(plainPassword);

      expect(hashedPassword).toBeDefined();
      expect(hashedPassword).not.toBe(plainPassword);

      // 2. Verify password comparison works
      const isPasswordValid = await service.comparePasswords(
        plainPassword,
        hashedPassword,
      );
      expect(isPasswordValid).toBe(true);

      // 3. Simulate login - generate token
      const user = {
        id: 'test-user-123',
        email: 'integration@test.com',
        role: 'user',
      };

      const loginResponse = await service.login(user);

      expect(loginResponse).toHaveProperty('access_token');
      expect(loginResponse).toHaveProperty('user');
      expect(loginResponse.user).toEqual(user);

      // 4. Verify token can be decoded
      const decodedToken = service.verifyToken(loginResponse.access_token);

      expect(decodedToken).toHaveProperty('userId', user.id);
      expect(decodedToken).toHaveProperty('email', user.email);
      expect(decodedToken).toHaveProperty('role', user.role);
      expect(decodedToken).toHaveProperty('iat'); // issued at
      expect(decodedToken).toHaveProperty('exp'); // expiration
    });

    it('should reject invalid tokens', async () => {
      const invalidToken = 'invalid.jwt.token.string';

      expect(() => service.verifyToken(invalidToken)).toThrow();
    });

    it('should handle password verification correctly', async () => {
      const password = 'MyPassword123';
      const hashedPassword = await service.hashPassword(password);

      // Correct password should verify
      const validCheck = await service.comparePasswords(password, hashedPassword);
      expect(validCheck).toBe(true);

      // Wrong password should not verify
      const invalidCheck = await service.comparePasswords(
        'WrongPassword',
        hashedPassword,
      );
      expect(invalidCheck).toBe(false);
    });

    it('should generate unique tokens for different users', async () => {
      const user1 = {
        id: 'user-1',
        email: 'user1@test.com',
        role: 'user',
      };

      const user2 = {
        id: 'user-2',
        email: 'user2@test.com',
        role: 'admin',
      };

      const login1 = await service.login(user1);
      const login2 = await service.login(user2);

      expect(login1.access_token).not.toBe(login2.access_token);

      const decoded1 = service.verifyToken(login1.access_token);
      const decoded2 = service.verifyToken(login2.access_token);

      expect(decoded1.userId).toBe(user1.id);
      expect(decoded2.userId).toBe(user2.id);
      expect(decoded1.role).toBe('user');
      expect(decoded2.role).toBe('admin');
    });

    it('should maintain password security - same password generates different hashes', async () => {
      const password = 'SamePassword123';

      const hash1 = await service.hashPassword(password);
      const hash2 = await service.hashPassword(password);

      // Hashes should be different (bcrypt includes random salt)
      expect(hash1).not.toBe(hash2);

      // But both should verify against the original password
      expect(await service.comparePasswords(password, hash1)).toBe(true);
      expect(await service.comparePasswords(password, hash2)).toBe(true);
    });
  });

  describe('Security Requirements', () => {
    it('should reject empty passwords', async () => {
      await expect(service.hashPassword('')).rejects.toThrow(
        'Password cannot be empty',
      );
    });

    it('should enforce password complexity through hashing', async () => {
      const weakPassword = 'weak';
      const strongPassword = 'StrongP@ssw0rd!2024';

      // Both should hash successfully (complexity enforcement happens at validation layer)
      const weakHash = await service.hashPassword(weakPassword);
      const strongHash = await service.hashPassword(strongPassword);

      expect(weakHash).toBeDefined();
      expect(strongHash).toBeDefined();

      // Hashes should be different lengths/patterns
      expect(weakHash.length).toBeGreaterThan(50);
      expect(strongHash.length).toBeGreaterThan(50);
    });
  });

  describe('Token Expiration', () => {
    it('should include expiration time in tokens', async () => {
      const user = {
        id: 'test-user',
        email: 'test@example.com',
        role: 'user',
      };

      const loginResponse = await service.login(user);
      const decodedToken = service.verifyToken(loginResponse.access_token);

      expect(decodedToken).toHaveProperty('exp');
      expect(decodedToken).toHaveProperty('iat');

      // Token should expire 1 hour from now (3600 seconds)
      const expiresIn = decodedToken.exp - decodedToken.iat;
      expect(expiresIn).toBe(3600);
    });
  });
});
